package tp4_3;

import java.time.LocalDate;

abstract public class ustensile {
	protected static int annee;
	
	public ustensile() {
		
	}
	public ustensile(int annee) {
		this.annee=annee;
	}
	@Override
	public String toString() {
		return "annee de fabrication :"+ annee;
	}
	public static int getCurrentYear() {
        return LocalDate.now().getYear();
    }
	abstract public double calculvaleur(); 
}
