package tp4_3;
public class assiettecarree extends assiette{
	double cote;
	
	public assiettecarree(int annee ,double cote) {
		super(annee);
		this.cote=cote;
	}
	public String toString() {
		return super.toString()+"et le cote :"+cote;
		
	}
	public double calculsurface() {
		double surface = (this.cote)*(this.cote);
		return surface;
	}
	   public double calculvaleur() {
		   AssietteRonde c= new AssietteRonde(this.annee);
		   return 2 * c.calculvaleur();
	   }

}
