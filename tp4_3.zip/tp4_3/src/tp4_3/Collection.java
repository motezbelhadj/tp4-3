package tp4_3;

public class Collection {
public static void main(String[] args) {
	ustensile[] us = new ustensile[5];
us[0] = new AssietteRonde(1926, 8.4);
us[1] = new cuillere(1881, 7.3);
us[2] = new assiettecarree(1935, 5.6);
us[3] = new cuillere(1917, 8.8);
us[4] = new AssietteRonde(1837, 5.4);
System.out.println("ceci notre collection :");
afficheCollection(us);
System.out.println("******************************************");
System.out.println("ceci les cuilleres :");
afficherCuilleres(us);
System.out.println("******************************************");
afficherSurfaceAssiettes(us);
System.out.println("******************************************");
affiche_valeurTotal(us);

}

private static void afficherSurfaceAssiettes(ustensile[] us) {
	double s=0;
	for(int i=0; i< us.length ;i++) {
		if(us[i] instanceof assiette) {
			s +=((assiette)us[i]).calculsurface() ;
		}
	}
			System.out.println("la somme des surfaces = "+ s);
		
	

}
private static void afficheCollection(ustensile[] us) {
	for(int i=0; i< us.length ;i++) {
		System.out.println(us[i].toString());
	}
}
	
private static void afficherCuilleres(ustensile[] us) {
	for(int i=0; i< us.length ;i++) {
		if(us[i] instanceof cuillere) {
			System.out.println(us[i].toString());
		}
	}
	}
private static void affiche_valeurTotal(ustensile[] us) {
	double sum= 0 ;
	for(int i=0; i< us.length ;i++) {
		sum +=us[i].calculvaleur();
		}
	System.out.println("la somme des valeurs = "+ sum);

}
}