package tp4_3;

public class AssietteRonde extends assiette {
    double rayon;
    
    public AssietteRonde(int annee, double rayon) {
    	super(annee); 
        this.rayon = rayon;
    }
    
    public AssietteRonde(int annee) {
    	super(annee); 
	}

	public String toString() {
        return super.toString() + " et le rayon : " + rayon;
    }
    public double calculsurface() {
		double surface = ((3.14)*(this.rayon))*this.rayon;
		return surface;
	}
    public double calculvaleur() {
    	int current_year=getCurrentYear();
    	
    	double valeur = current_year - this.annee;
    	if(valeur > 50) {
    	valeur =((valeur - 50) * 1);
    	return valeur;
    	}
    	else return 0;
    }
}
