package tp4_3;

abstract public class assiette extends ustensile {

	public assiette(int annee) {
		return;
	}
	abstract public double calculsurface();

}