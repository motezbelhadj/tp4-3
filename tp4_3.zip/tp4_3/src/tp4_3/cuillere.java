package tp4_3;

public class cuillere extends ustensile {
	double lang;
	
	public cuillere(int annee ,double lang) {
		super( annee);
		this.lang=lang;
	}
	public double getLang() {
		return this.lang;
	}
	public void setLang(int annee,int lang) {
		this.lang=lang;
	}
	public String toString() {
		return super.toString()+" et la langueure :"+lang;
	
	}
	  public double calculvaleur() {
	    	int current_year=getCurrentYear();
	    	
	    	double valeur = current_year - this.annee;
	    	if(valeur > 30) {
	    	valeur =(valeur * 0.5);
	    	return valeur;
	    	}
	    	else return 0;
	    }
}
